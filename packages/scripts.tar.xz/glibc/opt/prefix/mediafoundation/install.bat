@echo off

Z:\usr\glibc\opt\apps\7z.exe x dll.7z -oC:\windows -y
reg import mediafoundation.reg /reg:64