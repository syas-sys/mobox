@echo off
title Starting mono and gecko installer
echo Starting mono and gecko installer
wineboot -u
title Fixing prefix-tweaks
echo Fixing prefix-tweaks
regedit Z:\usr\glibc\opt\prefix\system.reg  >NUL 2>&1
regedit Z:\usr\glibc\opt\prefix\user.reg  >NUL 2>&1
Z:\usr\glibc\opt\apps\7z.exe x Z:\usr\glibc\opt\prefix\drive_c.7z -oC: -y >NUL 2>&1