echo Installing %installname%...
title Installing %installname%...

Z:\usr\glibc\opt\apps\7z.exe x Z:\usr\glibc\opt\libs\mesa\%installname%.7z -oZ:\usr\glibc -y >NUL 2>&1

cd /d "C:\ProgramData\Microsoft\Windows\Start Menu\Install" >NUL 2>&1
for /d %%a in (2.*) do (
	ren "C:\ProgramData\Microsoft\Windows\Start Menu\Install\%%a" "2.%startname%" >NUL 2>&1
)
cd /d Z:\usr\glibc\opt\prefix\mesa