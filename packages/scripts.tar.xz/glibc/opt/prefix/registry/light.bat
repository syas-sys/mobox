@echo off

regedit.exe /C Z:\usr\glibc\opt\prefix\registry\light.reg

set startname=Light theme

cd /d "C:\ProgramData\Microsoft\Windows\Start Menu\Registry" >NUL 2>&1
for /d %%a in (2.*) do (ren "%%a" "2.%startname%" >NUL 2>&1)
cd /d Z:\usr\glibc\opt\prefix\registry
echo Restarting
copy /y NUL Z:\usr\glibc\opt\reboot
pause >NUL