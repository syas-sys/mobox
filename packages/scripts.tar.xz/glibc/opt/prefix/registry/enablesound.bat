@echo off
reg delete HKCU\Software\Wine\Drivers /v Audio /f

set startname=Sound enabled

cd /d "C:\ProgramData\Microsoft\Windows\Start Menu\Registry" >NUL 2>&1
for /d %%a in (1.*) do (ren "%%a" "1.%startname%" >NUL 2>&1)
cd /d Z:\usr\glibc\opt\prefix\registry