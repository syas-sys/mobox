@echo off
copy /y NUL Z:\usr\glibc\opt\shutdown